// AULA 14 - Consumo de uma API falsa
// API pública de testes: https://jsonplaceholder.typicode.com/

const API_BASE = "https://jsonplaceholder.typicode.com";
// Sem internet? Troque a linha anterior para: http://localhost:3000

const btnCarregar = document.querySelector("#btn-carregar");
const btnErro = document.querySelector("#btn-erro");
const statusEl = document.querySelector("#status");
const listaEl = document.querySelector("#posts");

function atualizarStatus(mensagem, tipo = "") {
  statusEl.textContent = mensagem;
  statusEl.dataset.tipo = tipo;
}

function mostrarPublicacoes(publicacoes) {
  listaEl.replaceChildren();

  publicacoes.forEach((post) => {
    const cartao = document.createElement("article");
    cartao.className = "cartao";

    const numero = document.createElement("span");
    numero.className = "numero";
    numero.textContent = `PUBLICAÇÃO #${post.id}`;

    const titulo = document.createElement("h3");
    titulo.textContent = post.titulo;

    const descricao = document.createElement("p");
    descricao.textContent = post.descricao;

    cartao.append(numero, titulo, descricao);
    listaEl.append(cartao);
  });
}

async function carregarPublicacoes(caminho) {
  btnCarregar.disabled = true;
  btnErro.disabled = true;
  listaEl.replaceChildren();
  atualizarStatus("Consultando a API...", "carregando");

  try {
    const url = `${API_BASE}${caminho}`;
    console.log("Requisição GET:", url);

    // 1) O navegador (cliente) envia a requisição HTTP.
    const resposta = await fetch(url);
    console.log("Resposta HTTP:", resposta.status, resposta.statusText);

    // 2) Um HTTP 404 não gera erro automático no fetch().
    if (!resposta.ok) {
      throw new Error(`HTTP ${resposta.status}: não foi possível obter o recurso.`);
    }

    // 3) JSON é convertido em valores JavaScript (array e objetos).
    const dados = await resposta.json();
    if (!Array.isArray(dados)) {
      throw new Error("A resposta JSON não contém uma lista de publicações.");
    }
    console.log("JSON recebido:", dados);

    // 4) Manipulamos os objetos para exibir apenas os campos desejados.
    const publicacoes = dados.map((post) => ({
      id: post.id,
      titulo: post.title,
      descricao: post.body,
    }));

    // 5) Atualizamos a página sem recarregá-la (DOM).
    mostrarPublicacoes(publicacoes);
    atualizarStatus(
      `HTTP ${resposta.status}: ${publicacoes.length} publicações carregadas!`,
      "sucesso"
    );
  } catch (erro) {
    console.error("Falha ao consumir a API:", erro);
    atualizarStatus(`Falha na consulta: ${erro.message}`, "erro");
  } finally {
    // Os botões voltam a funcionar tanto no sucesso quanto no erro.
    btnCarregar.disabled = false;
    btnErro.disabled = false;
  }
}

btnCarregar.addEventListener("click", () => {
  carregarPublicacoes("/posts?_limit=5");
});

btnErro.addEventListener("click", () => {
  carregarPublicacoes("/posts/101"); // ID inexistente -> HTTP 404
});
